package assignment;
 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.*;
 
public class ViewCarPage extends JPanel {
    private JTable carTable;
    private JButton backButton;
 
    public ViewCarPage(ActionListener onBack) {
        setLayout(new BorderLayout());
 
        String[] columnNames = {"ID", "Model", "Price", "Features", "Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
 
        loadCarData(tableModel);
 
        carTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(carTable);
        add(scrollPane, BorderLayout.CENTER);
 
        backButton = new JButton("Back");
        backButton.addActionListener(onBack);
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);
    }
 
    private void loadCarData(DefaultTableModel tableModel) {
        File file = new File("store.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Could not create store.txt");
                return;
            }
        }
 
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length == 8) {
                    tableModel.addRow(parts);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading from store.txt: " + e.getMessage());
        }
    }
}