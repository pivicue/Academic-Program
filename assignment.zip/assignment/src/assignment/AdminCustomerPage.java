package assignment;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class AdminCustomerPage {
    private JFrame frame;
    private JPanel panel;
    private JButton searchCustomerButton, approveButton,backButton;
    
    public AdminCustomerPage(ActionListener onSearch,ActionListener onApprove,ActionListener onBack){
        frame = new JFrame("Salesman");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new GridLayout(4,1));
        
        searchCustomerButton = new JButton("Search Customer");
        approveButton = new JButton("Approve New Customer Account");
        backButton = new JButton("Back");
        
        panel.add(searchCustomerButton);
        panel.add(approveButton);
        panel.add(backButton);
        
        searchCustomerButton.addActionListener(onSearch);
        approveButton.addActionListener(onApprove);
        backButton.addActionListener(onBack);
    
    }
    public JPanel getPanel() {
        return panel;
    }
}
