package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Date;

public class RegisterAdminPage extends JPanel {
    private String username;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JCheckBox showPasswordCheckBox;
    private JSpinner DateOfBirthSpinner;
    private JTextField AddressField;
    private JTextField PhoneField;
    private JTextField EmailField;
    private JButton submitButton;
    private JButton backButton;
    private JTextField SuperAdminField;

    public RegisterAdminPage(String username, ActionListener onRegisterSuccess, ActionListener onBack) {
        this.username = username;
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        SuperAdminField = new JTextField();
        submitButton = new JButton("Submit");
        AddressField = new JTextField();
        PhoneField = new JTextField();
        EmailField = new JTextField();
        backButton = new JButton("Back");
        showPasswordCheckBox = new JCheckBox("Show Password");
        SpinnerDateModel dateModel = new SpinnerDateModel();
        DateOfBirthSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(DateOfBirthSpinner, "yyyy-MM-dd");
        DateOfBirthSpinner.setEditor(dateEditor);
        
        
        setLayout(new GridLayout(9, 2));
        add(new JLabel("New Username:"));
        add(usernameField);
        add(new JLabel("New Password:"));
        add(passwordField);
        add(showPasswordCheckBox);
        add(new JLabel());
        add(new JLabel("Date Of Birth"));
        add(DateOfBirthSpinner);
        add(new JLabel ("Address"));
        add(AddressField);
        add(new JLabel("Phone Number"));
        add(PhoneField);
        add(new JLabel("Email"));
        add(EmailField);
        add(new JLabel("Created By:"));
        add(SuperAdminField);
        add(submitButton);
        add(backButton);
        SuperAdminField.setEditable(false);
        
        loadUserInfo();
        
        showPasswordCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (showPasswordCheckBox.isSelected()) {
                    passwordField.setEchoChar((char) 0); 
                } else {
                    passwordField.setEchoChar('*');
                }
            }
        });

        submitButton.addActionListener(e -> {
            String newUsername = usernameField.getText();
            String newPassword = new String(passwordField.getPassword());
            String Address = AddressField.getText();
            String Phone = PhoneField.getText();
            String Email = EmailField.getText();
            Date DateOfBirth = (Date) DateOfBirthSpinner.getValue();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String DateOfBirthStr = sdf.format(DateOfBirth);
            if (newUsername.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter username!");
                return;
            }      
            
            if (newPassword.isEmpty() || newPassword.length()<6){
                JOptionPane.showMessageDialog(this, "Please enter password at least 6 digit!");
                return;
            }
            
            if (Address.isEmpty()){
                JOptionPane.showMessageDialog(this, "Please enter address!");
                return;
            }
            
            if (!Email.matches("^[A-Za-z0-9+_.-]+@gmail\\.com$")) {
                JOptionPane.showMessageDialog(this, "Invalid Email Format (Email must end with (@gmail.com)");
                return;
            }
            
            LocalDate dobLocal = DateOfBirth.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate today = LocalDate.now();
            Period age = Period.between(dobLocal, today);
            if (age.getYears() < 18) {
                JOptionPane.showMessageDialog(this, "You must be at least 18 years old to register!");
                return;
            }
            
            if (!Phone.matches("01\\d{8}")) {
                JOptionPane.showMessageDialog(this, "Phone number must start with 01 and have 10 digits!");
                return;
            }
            
            if (PhoneNumberExists(Phone)) {
                JOptionPane.showMessageDialog(this, "Phone Number already exists!");
                return;
            }
            
            if (gmailExists(Email)) {
                JOptionPane.showMessageDialog(this, "Email already exists!");
                return;
            }
            
            if (userExists(newUsername)) {
                JOptionPane.showMessageDialog(this, "Username already exists!");
            }else {
                registerUser(newUsername, newPassword, DateOfBirthStr, Address, Phone, Email);
                JOptionPane.showMessageDialog(this, "Register Successful!");
                onRegisterSuccess.actionPerformed(e); 
                clearFields();
            }
        });

        backButton.addActionListener(onBack); 
    }
    
    private boolean PhoneNumberExists(String phone) {
        try (BufferedReader br = new BufferedReader(new FileReader("Admin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] phoneNumber = line.split("/");
                if (phoneNumber.length >= 5 && phoneNumber[4].equals(phone)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
    private boolean gmailExists(String email) {
        try (BufferedReader br = new BufferedReader(new FileReader("Admin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] gmail = line.split("/");
                if (gmail.length >= 6 && gmail[5].equals(email)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private boolean userExists(String username) {
        try (BufferedReader br = new BufferedReader(new FileReader("Admin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userPass = line.split("/");
                if (userPass.length >= 1 && userPass[0].equals(username)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void registerUser(String username, String password, String DateOfBirth, String Address, String Phone, String Email) {    
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("Admin.txt", true))) {
            bw.write(username + "/" + password + "/" + DateOfBirth + "/" + Address + "/" + Phone + "/" + Email + "/" + this.username );
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
        
    public void setUsername(String username) {
        this.username = username;
    }
    
    private void clearFields() {
        usernameField.setText("");
        passwordField.setText("");
        DateOfBirthSpinner.setValue(new Date());
        AddressField.setText("");
        PhoneField.setText("");
        EmailField.setText("");
        SuperAdminField.setText(this.username);
    }

    public void loadUserInfo() {
        try (BufferedReader br = new BufferedReader(new FileReader("SuperAdmin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 6 && parts[0].equals(username)) {
                    SuperAdminField.setText(username);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
