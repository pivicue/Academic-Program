package assignment;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.*;
public class AdminMainPage {
     private JFrame frame;
     private JPanel panel;
     private JButton editAdminProfile, salesman, customer, deleteAdmin, searchCar ,backButton,feedbackButton;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    
     public AdminMainPage(ActionListener onProfile, ActionListener onSalesman, ActionListener onCustomer,ActionListener onCar, ActionListener onFeedback,ActionListener onBack){
         frame = new JFrame("AdminMainPage");
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         panel = new JPanel(new GridLayout(4,1));
         
         editAdminProfile = new JButton("Profile");
         salesman = new JButton("Salesman");
         customer = new JButton("Customer");
         searchCar = new JButton("Cars");
         feedbackButton = new JButton("Feedback Analysis");
         backButton = new JButton("Log Out");
         
         
         panel.add(editAdminProfile);
         panel.add(salesman);
         panel.add(customer);
         panel.add(searchCar);
         panel.add(feedbackButton);
         panel.add(backButton);
         
        editAdminProfile.addActionListener(onProfile);
        salesman.addActionListener(onSalesman);
        customer.addActionListener(onCustomer);
        searchCar.addActionListener(onCar);
        feedbackButton.addActionListener(onFeedback);
        backButton.addActionListener(onBack);
        
         
                 
         frame.add(panel);
         frame.pack();
         
         
     
}
     public JPanel getPanel() {
        return panel;
    }
}


    

