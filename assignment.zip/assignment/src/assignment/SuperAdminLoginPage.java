package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.function.Consumer;
public class SuperAdminLoginPage extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox showPasswordCheckBox;
    private JButton submitButton;
    private JButton backButton;
    private JTextField verificationField;

    public SuperAdminLoginPage(Consumer<String> onLoginSuccess, ActionListener onBack)  {
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        verificationField = new JTextField();
        submitButton = new JButton("Log In");
        backButton = new JButton("Back");
        showPasswordCheckBox = new JCheckBox("Show Password");
        
        setLayout(new GridLayout(5, 2));
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(showPasswordCheckBox);
        add(new JLabel());
        add (new JLabel("Verification Code:"));
        add(verificationField);
        add(submitButton);
        add(backButton);
        
        showPasswordCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (showPasswordCheckBox.isSelected()) {
                    passwordField.setEchoChar((char) 0); 
                } else {
                    passwordField.setEchoChar('*');
                }
            }
        });

        submitButton.addActionListener(e -> {
            String verification = verificationField.getText();
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            
            if (!verification.equals("852456")){
                JOptionPane.showMessageDialog(this, "Please enter correct verification code!");
                return;
            }

            if (checkLogin(username,password)) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                onLoginSuccess.accept(username);
                usernameField.setText("");
                passwordField.setText("");
                verificationField.setText("");
                 
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password");
            }
        });

        backButton.addActionListener(onBack); 
    }

    private boolean checkLogin(String username, String password) {
        try (BufferedReader br = new BufferedReader(new FileReader("SuperAdmin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userPass = line.split("/");
                if (userPass.length >=2 && userPass[0].equals(username) && userPass[1].equals(password)) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}

    



