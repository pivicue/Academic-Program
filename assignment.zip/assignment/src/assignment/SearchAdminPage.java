package assignment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SearchAdminPage extends JPanel {
    private static final String FILE_NAME = "Admin.txt";
    private static final String VERIFICATION_CODE = "852456";

    private JTable table;
    private DefaultTableModel model;
    private JTextArea detailArea;
    private JButton deleteButton, backButton, searchButton, resetButton, refreshButton;
    private JTextField searchField;

    private List<Admin> adminList = new ArrayList<>();
    private List<Admin> filteredList = new ArrayList<>();

    public SearchAdminPage(ActionListener onBack) {
        setLayout(new BorderLayout());

        
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(20);
        refreshButton = new JButton("Refresh");
        searchButton = new JButton("Search");
        resetButton = new JButton("X");

        searchPanel.add(new JLabel("Search Admin:"));
        searchPanel.add(refreshButton);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(resetButton);
        add(searchPanel, BorderLayout.NORTH);

      
        model = new DefaultTableModel(new String[]{"Admin", "Phone Number", "Gmail", "Created By"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        table.setAutoCreateRowSorter(true); // Sortable columns
        JScrollPane tableScrollPane = new JScrollPane(table);

        // Right: Detail Panel
        detailArea = new JTextArea(8, 30);
        detailArea.setEditable(false);
        JScrollPane detailScrollPane = new JScrollPane(detailArea);

        deleteButton = new JButton("Delete Selected Admin");
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(detailScrollPane, BorderLayout.CENTER);
        rightPanel.add(deleteButton, BorderLayout.SOUTH);

      
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, tableScrollPane, rightPanel);
        add(splitPane, BorderLayout.CENTER);

      
        backButton = new JButton("Back");
        backButton.addActionListener(onBack);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);

       
        loadAdminFromFile();
        refreshTable(adminList);

        
        refreshButton.addActionListener(e -> {
            loadAdminFromFile();
            refreshTable(adminList);
        });

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0 && row < filteredList.size()) {
                    Admin selected = filteredList.get(row);
                    detailArea.setText(selected.toDetailString());
                }
            }
        });

        deleteButton.addActionListener(e -> handleDelete());

        searchButton.addActionListener(e -> handleSearch());

        resetButton.addActionListener(e -> {
            searchField.setText("");
            filteredList = new ArrayList<>(adminList);
            refreshTable(filteredList);
            detailArea.setText("");
        });
    }

    private void handleSearch() {
        String keyword = searchField.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter keyword");
            return;
        }

        filteredList = new ArrayList<>();
        for (Admin a : adminList) {
            if (a.admin.toLowerCase().contains(keyword)
                    || a.phoneNumber.toLowerCase().contains(keyword)
                    || a.gmail.toLowerCase().contains(keyword)
                    || a.address.toLowerCase().contains(keyword)) {
                filteredList.add(a);
            }
        }
        refreshTable(filteredList);
        detailArea.setText("");
    }

    private void handleDelete() {
        int row = table.getSelectedRow();
        if (row >= 0 && row < filteredList.size()) {
            Admin selected = filteredList.get(row);
            int confirm = JOptionPane.showConfirmDialog(this, "Delete admin: " + selected.admin + " ?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                String inputCode = showVerificationDialog("Enter verification code:");
                if (VERIFICATION_CODE.equals(inputCode)) {
                    adminList.remove(selected);
                    filteredList.remove(row);
                    refreshTable(filteredList);
                    detailArea.setText("");
                    saveAdminsToFile();
                    JOptionPane.showMessageDialog(this, "Admin deleted.");
                } else {
                    JOptionPane.showMessageDialog(this, "Incorrect verification code.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an admin.");
        }
    }

    private void refreshTable(List<Admin> list) {
        model.setRowCount(0);
        for (Admin a : list) {
            model.addRow(new Object[]{a.admin, a.phoneNumber, a.gmail, a.superAdmin});
        }
    }

    private void loadAdminFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        adminList.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 7) {
                    Admin a = new Admin(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]);
                    adminList.add(a);
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error loading " + FILE_NAME + ": " + ex.getMessage());
        }
        filteredList = new ArrayList<>(adminList);
    }

    private void saveAdminsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Admin a : adminList) {
                writer.write(a.toFileString());
                writer.newLine();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving " + FILE_NAME + ": " + ex.getMessage());
        }
    }

    private String showVerificationDialog(String message) {
        JPasswordField passwordField = new JPasswordField();
        int option = JOptionPane.showConfirmDialog(this, passwordField, message, JOptionPane.OK_CANCEL_OPTION);
        return (option == JOptionPane.OK_OPTION) ? new String(passwordField.getPassword()) : null;
    }

    static class Admin {
        String admin, password, dob, address, phoneNumber, gmail, superAdmin;

        public Admin(String admin, String password, String dob, String address, String phoneNumber, String gmail, String superAdmin) {
            this.admin = admin;
            this.password = password;
            this.dob = dob;
            this.address = address;
            this.phoneNumber = phoneNumber;
            this.gmail = gmail;
            this.superAdmin = superAdmin;
        }

        public String toDetailString() {
            return String.format(
                "Admin: %s\nDate of Birth: %s\nAddress: %s\nPhone Number: %s\nGmail: %s\nCreated By: %s",
                admin, dob, address, phoneNumber, gmail, superAdmin
            );
        }

        public String toFileString() {
            return String.join("/", admin, password, dob, address, phoneNumber, gmail, superAdmin);
        }
    }
}
