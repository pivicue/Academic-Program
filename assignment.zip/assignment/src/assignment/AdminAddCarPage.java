package assignment;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;

public class AdminAddCarPage {
    private String adminUsername;
    private JFrame frame;
    private JPanel panel;
    private JButton confirmButton,backButton;
    private JTextField modelField, minPriceField, maxPriceField,featureField, quantitiesField;
    
    
    public AdminAddCarPage(String username, ActionListener onBack){
        this.adminUsername = username;
        
        frame = new JFrame("Add New Car(s)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new GridLayout(6,2));
        
        modelField = new JTextField();
        minPriceField = new JTextField();
        maxPriceField = new JTextField();
        featureField = new JTextField();
        quantitiesField = new JTextField();
        confirmButton = new JButton("Confirm");
        backButton = new JButton("Back");
        
        
        panel.add(new JLabel("Model:"));
        panel.add(modelField);
        panel.add(new JLabel("Minimun Price:"));
        panel.add(minPriceField);
        panel.add(new JLabel("Maximun Price:"));
        panel.add(maxPriceField);
        panel.add(new JLabel("Features:"));
        panel.add(featureField);
        panel.add(new JLabel("Quantity"));
        panel.add(quantitiesField);
        panel.add(confirmButton);
        panel.add(backButton);
        
        confirmButton.addActionListener(e -> {
            ensureFileExists();
            String model = modelField.getText().toUpperCase();
            String minPrice = minPriceField.getText();
            String maxPrice = maxPriceField.getText();
            String feature = featureField.getText();
            String quantityText = quantitiesField.getText().trim();   
            
            if (model.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter model!");
                return;
        }if (minPrice.isEmpty() || maxPrice.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter minimum and maximum price!");
                return;
        }if (feature.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter feature or enter '-'!");
                return;
        }if (quantityText.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter a value!");
                return;
        }if(checkInt()){
            try {
                int quantity = Integer.parseInt(quantityText);
                if (quantity <= 0) {
                    JOptionPane.showMessageDialog(frame, "Quantity must be greater than 0!");
                    return;
                }
                
                String ID = generateNextID();
                if (ID.equals("ERROR ID")) {
                    return;
                }
                
                if (quantity > 1) {
                    for (int i = 0; i < quantity; i++) {
                        addCars(ID, model, minPrice, maxPrice, feature);
                    
                        ID = generateNextID();
                    }
                    JOptionPane.showMessageDialog(frame, "Successfully added " + quantity + " cars");
                } else {
                    addCars(ID, model, minPrice,maxPrice, feature);
                    JOptionPane.showMessageDialog(frame, "Successfully added 1 car");
                }
                
                modelField.setText("");
                minPriceField.setText("");
                maxPriceField.setText("");
                featureField.setText("");
                quantitiesField.setText("");
                
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Quantity must be a valid number!");
            }
        }
        });
        
        backButton.addActionListener(onBack);    
        frame.add(panel);
        frame.pack();
    }
    
    private void addCars( String ID, String model, String minPrice,String maxPrice, String feature) {    
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("store.txt", true))){
            bw.write(ID + "/" + model + "/" + minPrice +"/"+maxPrice+ "/" + feature + "/available/-/"+adminUsername );
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private String generateNextID() {
        int highestNumber = 0;
        try (BufferedReader br = new BufferedReader(new FileReader("store.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("C")) {
                    try {
                        String idPart = line.split("/")[0];
                        int currentNum = Integer.parseInt(idPart.substring(1));
                        highestNumber = Math.max(highestNumber, currentNum);
                    } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                        continue;
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error in getting ID...");
            return "ERROR ID";
        }
        return String.format("C%03d", highestNumber + 1);
    }
    
    private boolean checkInt() {
    try {
        int minPrice = Integer.parseInt(minPriceField.getText().trim());
        int maxPrice = Integer.parseInt(maxPriceField.getText().trim());
        int quantity = Integer.parseInt(quantitiesField.getText().trim());
        if (minPrice>maxPrice){
            JOptionPane.showMessageDialog(frame, "Maximum price must greater than minimum price!");
            return false;
        }
        if (minPrice < 0 || maxPrice < 0) {
            JOptionPane.showMessageDialog(frame, "Prices cannot be negative");
            return false;
        }
        if (quantity <= 0) {
            JOptionPane.showMessageDialog(frame, "Quantity must be greater than 0!");
            return false;
        }
        return true;
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(frame, "Please enter valid numbers for prices and quantity!");
        return false;
    }
}
    
    public void ensureFileExists() {
    File storeFile = new File("store.txt");
    
    if (!storeFile.exists()) {
        try {
            storeFile.createNewFile();
            System.out.println("Created new store.txt file");
        } catch (IOException e) {
            System.err.println("Failed to create store.txt: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
            
            
    public void setUsername(String username) {
    this.adminUsername = username;
}
   
    public JPanel getPanel() {
        return panel;
    }
    
}
