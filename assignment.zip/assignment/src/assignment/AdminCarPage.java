package assignment;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.*;

public class AdminCarPage {
    private JFrame frame;
    private JPanel panel;
    private JButton searchCarButton, addCarButton,backButton;
    
    public AdminCarPage(ActionListener onSearch,ActionListener onAdd,ActionListener onBack){
        frame = new JFrame("Car");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new GridLayout(4,1));
        
        searchCarButton = new JButton("Search Vehicle");
        addCarButton = new JButton("Add New Vehicle");
        backButton = new JButton("Back");
        
        panel.add(searchCarButton);
        panel.add(addCarButton);
        panel.add(backButton);
        
        searchCarButton.addActionListener(onSearch);
        addCarButton.addActionListener(onAdd);
        backButton.addActionListener(onBack);
    
    }
    public JPanel getPanel() {
        return panel;
    }
        
    }