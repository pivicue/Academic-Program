package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
public class SalesmenHomePage extends JPanel{
    private JButton ProfileButton;
    private JButton UpdateButton;
    private JButton PaymentButton;
    private JButton ViewButton;
    private JButton LogOutButton;
    public SalesmenHomePage (ActionListener onProfile, ActionListener onUpdate, ActionListener onPayment, ActionListener onView,ActionListener onLogOut){
        ProfileButton = new JButton("Profile");
        UpdateButton = new JButton("Update car status");
        PaymentButton = new JButton("Collect payment & Comment");
        ViewButton = new JButton("View sales record");
        LogOutButton = new JButton("Logout");
        setLayout (new GridLayout(4,1));
        add(ProfileButton);
        add(UpdateButton);
        add(PaymentButton);
        add(ViewButton);
        add(LogOutButton);
        ProfileButton.addActionListener(onProfile);
        UpdateButton.addActionListener(onUpdate);
        PaymentButton.addActionListener(onPayment);
        ViewButton.addActionListener(onView);
        LogOutButton.addActionListener(onLogOut);
    }
}