package assignment;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.Timer;

public class ViewSalesRecordPage extends JPanel {
    private String username;
    private JTable salesTable;
    private DefaultTableModel tableModel;
    private JButton backButton;
    private Timer refreshTimer;
    private TableRowSorter<TableModel> sorter;

    public ViewSalesRecordPage(String username, ActionListener onBack) {
        this.username = username;
        setLayout(new BorderLayout(10, 10));

        tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new String[]{
            "Customer", "CarID", "Car Model", "Amount Due", "Comment", "Payment Method"
        });

        salesTable = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        salesTable.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(salesTable);

        sorter = new TableRowSorter<>(tableModel);
        salesTable.setRowSorter(sorter);

        backButton = new JButton("Back");
        backButton.addActionListener(onBack);

        add(scrollPane, BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);

        refreshData();
        refreshTimer = new Timer(2000, e -> refreshData());
        refreshTimer.start();
    }

    public void refreshData() {
        tableModel.setRowCount(0);

        File saleFile = new File("sale.txt");
        File storeFile = new File("store.txt");

        if (!saleFile.exists() || !storeFile.exists()) {
            return;
        }

        Map<String, String> carSalesmanMap = new HashMap<>();
        try (BufferedReader storeReader = new BufferedReader(new FileReader(storeFile))) {
            String line;
            while ((line = storeReader.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 8) {
                    String ID = parts[0];
                    String Salesman = parts[6];
                    carSalesmanMap.put(ID, Salesman);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading store.txt: " + e.getMessage());
            return;
        }

        try (BufferedReader saleReader = new BufferedReader(new FileReader(saleFile))) {
            String line;
            while ((line = saleReader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 6) {
                        String ID = parts[1];
                        String Salesman = carSalesmanMap.get(ID);
                        if (Salesman != null && Salesman.equals(username)) {
                            tableModel.addRow(parts);
                        }
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading sale.txt: " + e.getMessage());
        }
    }

    public void stopAutoRefresh() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
    }

    public void startAutoRefresh() {
        if (refreshTimer != null && !refreshTimer.isRunning()) {
            refreshTimer.start();
        }
    }

    public void setUsername(String username) {
        this.username = username;
        refreshData(); 
    }
}






