package assignment;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
public class AdminSearchCarPage {
     private JTable carTable;
     private DefaultTableModel tableModel;
     private JPanel panel,topPanel,bottomPanel,formBottomPanel,formPanel;
     private JFrame frame,editFrame;
     private JButton searchButton,backButton, refreshButton,editButton,saveButton,cancelButton,deleteButton;
     private JTextField searchField,modelField, minPriceField, maxPriceField,featureField;
     private JCheckBox statusBox;
     private JComboBox<String> searchOption;
     private int[] selectedRows;
     private long lastFileModified;
     private String currentModel,currentCarID,adminUsername;
     private List<String> currentCarIDs = new ArrayList<>();
     private List<String> currentCarModel = new ArrayList<>();
     private List<String> currentPriceRange = new ArrayList<>();
     private List<String> currentStatus = new ArrayList<>();
     private List<String> currentFeature = new ArrayList<>();
     
     
     public AdminSearchCarPage(String username, ActionListener onBack) {
        this.adminUsername = username;
        
        frame = new JFrame("Search Car");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new BorderLayout());
        
        String[] columnNames = {"ID", "Model", "Price", "Features", "Status","Salesman","Added By"};
        tableModel = new DefaultTableModel(columnNames, 0) {
        @Override
            public boolean isCellEditable(int row, int column) {
            return false;
    }
};

        carTable = new JTable(tableModel);
        carTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        panel.add(carTable);
        JScrollPane scrollPane = new JScrollPane(carTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        String[] searchOptions = {"-","ID", "Model","Salesman","Added by"};
        searchOption = new JComboBox<>(searchOptions);
        
        topPanel = new JPanel();
        searchField = new JTextField(15);
        searchButton = new JButton("Search");
        statusBox = new JCheckBox("Show Available cars only",false);
        refreshButton = new JButton("Refresh");
        topPanel.add(refreshButton);
        topPanel.add(searchOption);
        topPanel.add(new JLabel("Search:"));
        topPanel.add(searchField);
        topPanel.add(searchButton);
        topPanel.add(statusBox);
        panel.add(topPanel, BorderLayout.NORTH);
        
        refreshButton.addActionListener(e -> startAutoRefresh(tableModel));
        searchButton.addActionListener(e -> filterCars(tableModel));
        searchField.addActionListener(e -> filterCars(tableModel));
        statusBox.addActionListener(e -> filterCars(tableModel));
        
        backButton = new JButton("Back");
        editButton = new JButton("Edit");
        editButton.addActionListener(e ->editPage());
        backButton.addActionListener(onBack);
        bottomPanel = new JPanel();
        bottomPanel.add(editButton);
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
       
        frame.add(panel);
        frame.pack();
        
        loadCarData(tableModel);
        
}
     public void loadCarData(DefaultTableModel tableModel) {
        File file = new File("store.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(frame, "Could not create store.txt");
                return;
            }
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            tableModel.setRowCount(0);
            
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length == 8) {
                    Object[] rowData = {parts[0], parts[1], parts[2]+"-"+parts[3], parts[4], parts[5], parts[6], parts[7]};
                    tableModel.addRow(rowData);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error reading from store.txt: " + e.getMessage());
        }
    }
    private void filterCars(DefaultTableModel tableModel){
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
    carTable.setRowSorter(sorter);
    
    List<RowFilter<DefaultTableModel, Integer>> filters = new ArrayList<>();
    String searchText = searchField.getText().trim();
    sorter.setRowFilter(RowFilter.andFilter(filters));
    
    if (!searchText.isEmpty()) {
        String selectedOption = (String) searchOption.getSelectedItem();
        String safeSearchText = Pattern.quote(searchText);

       
        switch (selectedOption) {
            case "ID":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 0));
                break;
            case "Model":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 1));
                break;
            case "Salesman":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 5));
                break;
            case "Added by":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 6));
                break;
            case "-":
            default:
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText));
                break;
        }
    }
    if (statusBox.isSelected()){
        filters.add(RowFilter.regexFilter("(?i)available", 4));
                   
    }
    if (!filters.isEmpty()) {
            sorter.setRowFilter(RowFilter.andFilter(filters));
       }else {
            sorter.setRowFilter(null); 
        }
    }
    
    private void editPage(){
         if (!checkField()) {
             return;
         }
        
        editFrame = new JFrame("Edit Car Information");
        editFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        panel = new JPanel(new BorderLayout());
        editFrame.setSize(800, 600);
        editFrame.setLocationRelativeTo(null);
        
        modelField = new JTextField();
        modelField.setEditable(false);
        minPriceField = new JTextField();
        maxPriceField = new JTextField();
        featureField = new JTextField();
        
        formPanel = new JPanel(new GridLayout(5, 2));
        formPanel.add(new JLabel("Model:"));
        formPanel.add(modelField);
        formPanel.add(new JLabel("Minimun Price:"));
        formPanel.add(minPriceField);
        formPanel.add(new JLabel("Maximun Price:"));
        formPanel.add(maxPriceField);
        formPanel.add(new JLabel("Features:"));
        formPanel.add(featureField);
        
        formBottomPanel = new JPanel(new GridLayout(1,3));
        saveButton =new JButton("Save");
        saveButton.addActionListener(e-> saveChange());
        formBottomPanel.add(saveButton);
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(e-> deleteCar());
        formBottomPanel.add(deleteButton);
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e-> editFrame.dispose());
        formBottomPanel.add(cancelButton);
        
        editFrame.add(formPanel,BorderLayout.CENTER);
        editFrame.add(formBottomPanel,BorderLayout.SOUTH);
        editFrame.setVisible(true);
        
        loadCar();
    }

    private void loadCar(){
        try (BufferedReader br = new BufferedReader(new FileReader("store.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 8 && parts[0].equals(currentCarID)) {
                    modelField.setText(currentModel);
                    minPriceField.setText(parts[2]);
                    maxPriceField.setText(parts[3]);
                    featureField.setText(parts[4]);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void saveChange() {
        String allCarID = String.join(",",currentCarIDs);
        String model = modelField.getText().toUpperCase();
        String minPrice = minPriceField.getText();
        String maxPrice = maxPriceField.getText();
        String feature = featureField.getText();
        
        try(BufferedReader reader = new BufferedReader(new FileReader("store.txt"))) {
        ArrayList<String> lines = new ArrayList<>();
        String line;
        
        int confirm = JOptionPane.showConfirmDialog(frame, 
                "Confirm make changes to " + allCarID + "?", "Confirm make changes", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
        
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("/");
            
            if (model.isEmpty())
                model = parts[1];
            if(minPrice.isEmpty())
                minPrice = parts[2];
            if(maxPrice.isEmpty())
                maxPrice = parts[3];
            if(feature.isEmpty())
                feature = parts[4];
        
            if(checkInt() && currentCarIDs.contains(parts[0])){
                parts[1] = model;
                parts[2] = minPrice;
                parts[3] = maxPrice;
                parts[4] = feature;
                parts[7] = adminUsername;
                line = String.join("/", parts);
            }
            lines.add(line);
    
        }
        reader.close();
        
        try (PrintWriter writer = new PrintWriter(new FileWriter("store.txt"))) {
            for (String updatedLine : lines) {
                writer.println(updatedLine);
            }
        }        
        }catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(editFrame, "Failed to update: " + e.getMessage());
    }
        JOptionPane.showMessageDialog(frame, "Car ID--"+allCarID+ " make changes successfully!");
        editFrame.dispose();
        loadCarData(tableModel);
    }
    
    public void deleteCar(){
        String allCarID = String.join(",",currentCarIDs);
        if (allCarID == null || allCarID.isEmpty()) {
        JOptionPane.showMessageDialog(frame, "Please select a customer account to delete");
        return;
    }
        int confirm = JOptionPane.showConfirmDialog(frame, 
            "Are you sure you want to delete " + allCarID + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
        return; 
        }
        
        
        List<String> lines = new ArrayList<>();
        try(BufferedReader reader = new BufferedReader(new FileReader("store.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
            String[] parts = line.split("/");
                 if (parts.length >= 6 && !currentCarIDs.contains(parts[0])) {
                    lines.add(line); 
                 }
            }
        }catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(editFrame, "Failed to update: " + e.getMessage());
    }
        try (PrintWriter writer = new PrintWriter(new FileWriter("store.txt"))) {
        for (String line : lines) {
            writer.println(line);
        }
        
    } catch (IOException e) {
        JOptionPane.showMessageDialog(frame, "Error writing file: " + e.getMessage());
    }
        JOptionPane.showMessageDialog(frame, "Car ID--"+allCarID+ " deleted successfully!");
        editFrame.dispose();
        loadCarData(tableModel);
    }
    
    private boolean checkInt() {
    String minText = minPriceField.getText().trim();
    String maxText = maxPriceField.getText().trim();
    
    try {
        int minPrice = Integer.parseInt(minText);
        int maxPrice = Integer.parseInt(maxText);
        
        if (minPrice < 0 || maxPrice < 0) {
            throw new IllegalArgumentException("Prices cannot be negative");
        }
        if (minPrice > maxPrice) {
            throw new IllegalArgumentException("Maximum price must be greater than minimum price");
        }
        return true;
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(frame, "Please enter valid numbers for prices");
        return false;
    } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(frame, e.getMessage());
        return false;
    }
}
        
    
    private void startAutoRefresh(DefaultTableModel tableModel) {
            File file = new File("store.txt");
            if (file.lastModified() > lastFileModified) {
                loadCarData(tableModel);
            }
        }

    private boolean checkField() {        
    currentCarIDs.clear();
    currentCarModel.clear();
    currentPriceRange.clear();
    currentFeature.clear();
    currentStatus.clear();
    
    selectedRows = carTable.getSelectedRows();
    
    if (selectedRows.length == 0) {
        JOptionPane.showMessageDialog(frame, "Please select at least one car");
        return false;
    }
    

    for (int row : selectedRows) {
        int modelRow = carTable.convertRowIndexToModel(row);
        currentCarID = (String) tableModel.getValueAt(modelRow,0);
        currentCarIDs.add((String) tableModel.getValueAt(modelRow, 0));
        currentCarModel.add((String) tableModel.getValueAt(modelRow, 1));
        currentPriceRange.add((String)tableModel.getValueAt(modelRow,2));
        currentFeature.add((String)tableModel.getValueAt(modelRow,3));
        currentStatus.add((String)tableModel.getValueAt(modelRow, 4));
    }
    
    boolean allAvailable = true;
    for (String status : currentStatus) {
        if (!status.equalsIgnoreCase("Available")) {
            allAvailable = false;
            break;
        }
    }
    if (!allAvailable) {
        JOptionPane.showMessageDialog(frame, "You can only make changes to available cars");
        return false;
    }
    
    currentModel = currentCarModel.get(0);
    boolean sameModel = true;
    for (String model : currentCarModel) {
        if (!model.equals(currentModel)) {
            sameModel = false;
            break;
        }
    }
    if (!sameModel) {
        JOptionPane.showMessageDialog(frame, "You cannot edit different car models at once");
        return false;
    }
    
    boolean sameFeature = true;
    String firstFeature = currentFeature.get(0);
    for (String feature : currentFeature) {
        if (!feature.equals(firstFeature)) {
            sameFeature = false;
            break;
        }
    }
    if (!sameFeature) {
        int confirm = JOptionPane.showConfirmDialog(frame, 
            "You have selected cars with different features. Continue?", 
            "Confirm Make Changes", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return false;
        }
    }
    
    boolean samePriceRange = true;
    String firstPriceRange = currentPriceRange.get(0);
    for (String priceRange : currentPriceRange) {
        if (!priceRange.equals(firstPriceRange)) {
            samePriceRange = false;
            break;
        }
    }
    if (!samePriceRange) {
        int confirm = JOptionPane.showConfirmDialog(frame, 
            "You have selected cars with different price ranges. Continue?", 
            "Confirm Make Changes", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return false;
        }
    }
    
    return true;
}
    
    public void setUsername(String username) {
    this.adminUsername = username;
}
            
    public JPanel getPanel(){
         return panel;
     }
}