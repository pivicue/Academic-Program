package assignment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class CustomerProfilePage extends JPanel {
    private String username;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField addressField;
    private JTextField phoneField;
    private JTextField emailField;
    private JTextField dateOfBirthField;
    private JButton backButton;
    private JButton editPasswordButton;
    private JButton editAddressButton;
    private JButton editPhoneButton;
    private JButton editEmailButton;
    public CustomerProfilePage(String username, ActionListener onBack) {
        this.username = username;
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        addressField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();
        dateOfBirthField = new JTextField();
        usernameField.setEditable(false);
        passwordField.setEditable(false);
        addressField.setEditable(false);
        phoneField.setEditable(false);
        emailField.setEditable(false);
        dateOfBirthField.setEditable(false);
        backButton = new JButton("Back");
        editPasswordButton = new JButton("Edit");
        editAddressButton = new JButton("Edit");
        editPhoneButton = new JButton("Edit");
        editEmailButton = new JButton("Edit");
        setLayout(new GridLayout(7, 3, 5, 5));
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel());
        add(new JLabel("Password:"));
        add(passwordField);
        add(editPasswordButton);
        add(new JLabel("Date Of Birth:"));
        add(dateOfBirthField);
        add(new JLabel());
        add(new JLabel("Address:"));
        add(addressField);
        add(editAddressButton);
        add(new JLabel("Phone Number:"));
        add(phoneField);
        add(editPhoneButton);
        add(new JLabel("Email:"));
        add(emailField);
        add(editEmailButton);
        add(new JLabel());
        add(backButton);
        add(new JLabel());
        loadUserInfo();

        editPasswordButton.addActionListener(e -> promptAndUpdate("Password"));

        editAddressButton.addActionListener(e -> promptAndUpdate("Address"));

        editPhoneButton.addActionListener(e -> promptAndUpdate("Phone"));

        editEmailButton.addActionListener(e -> promptAndUpdate("Email"));

        backButton.addActionListener(onBack);

    }
 
    public void setUsername(String username) {

        this.username = username;

    }
 
    public void loadUserInfo() {
        
        ensureFileExists();

        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {

            String line;

            while ((line = br.readLine()) != null) {

                String[] parts = line.split("/");

                if (parts.length >= 6 && parts[0].equals(username)) {

                    usernameField.setText(username);

                    passwordField.setText(parts[1]);

                    dateOfBirthField.setText(parts[2]);

                    addressField.setText(parts[3]);

                    phoneField.setText(parts[4]);

                    emailField.setText(parts[5]);

                    break;

                }

            }

        } catch (IOException e) {

            e.printStackTrace();

        }

    }
 
    private void promptAndUpdate(String field) {

    if (field.equals("Password")) {

        String oldPasswordInput = showPasswordInputDialog(this, "Enter current password:");

        if (oldPasswordInput == null || !oldPasswordInput.equals(new String(passwordField.getPassword()))) {

        JOptionPane.showMessageDialog(this, "Incorrect password.");

        return;

        }
 
        String newPassword = showPasswordInputDialog(this, "Enter new password:");

        if (newPassword.equals(oldPasswordInput)){

            JOptionPane.showMessageDialog(this, "Please enter a new Password");

            return;

        }

        else if (newPassword.length()<6 || newPassword.isEmpty()){

                JOptionPane.showMessageDialog(this, "Please enter password at least 6 digit!");

                return;

            }
        
      
        updateFieldInFile(field, newPassword);

        loadUserInfo();

        return;

    }

    String current = switch (field) {

        case "Address" -> addressField.getText();

        case "Phone" -> phoneField.getText();

        case "Email" -> emailField.getText();

        default -> "";

    };
 
    String input = JOptionPane.showInputDialog(this, "Enter new " + field + ":", current);

    if (input == null || input.trim().isEmpty()) return;

    input = input.trim();
 
    if (field.equals("Phone")) {

        if (!input.matches("01\\d{8}")) {

            JOptionPane.showMessageDialog(this, "Please enter a correct phone number.");

            return;

        }

        if (PhoneNumberExists(input)) {

            JOptionPane.showMessageDialog(this, "Phone number already exists.");

            return;

        }

    }
 
    if (field.equals("Email")) {

        if (!input.matches("^[A-Za-z0-9+_.-]+@gmail\\.com$")) {

            JOptionPane.showMessageDialog(this, "Invalid Gmail format.");

            return;

        }

        if (gmailExists(input)) {

            JOptionPane.showMessageDialog(this, "Gmail already exists.");

            return;

        }

    }
 
    updateFieldInFile(field, input);

    loadUserInfo();

}
 
    private String showPasswordInputDialog(Component parent, String message) {

    JPanel panel = new JPanel(new BorderLayout());

    JLabel label = new JLabel(message);

    JPasswordField passwordField = new JPasswordField(15);

    JCheckBox showPasswordCheckBox = new JCheckBox("Show Password");
 
    showPasswordCheckBox.addActionListener(e -> {

        passwordField.setEchoChar(showPasswordCheckBox.isSelected() ? (char) 0 : '•');

    });
 
    JPanel inputPanel = new JPanel(new BorderLayout());

    inputPanel.add(passwordField, BorderLayout.CENTER);

    inputPanel.add(showPasswordCheckBox, BorderLayout.SOUTH);
 
    panel.add(label, BorderLayout.NORTH);

    panel.add(inputPanel, BorderLayout.CENTER);
 
    int option = JOptionPane.showConfirmDialog(parent, panel, "Password", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (option == JOptionPane.OK_OPTION) {

        return new String(passwordField.getPassword()).trim();

    } else {
        
        JOptionPane.showMessageDialog(parent, "Failed to edit password");

        return null;

    }

}

    private void updateFieldInFile(String field, String newValue) {

        try {

            File inputFile = new File("users.txt");

            File tempFile = new File("users_temp.txt");
 
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));

            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
 
            String line;

            while ((line = reader.readLine()) != null) {

                String[] parts = line.split("/");

                if (parts.length >= 6 && parts[0].equals(username)) {

                    switch (field) {

                        case "Password" -> parts[1] = newValue;

                        case "Address" -> parts[3] = newValue;

                        case "Phone" -> parts[4] = newValue;

                        case "Email" -> parts[5] = newValue;

                    }

                    line = String.join("/", parts);

                }

                writer.write(line);

                writer.newLine();

            }
 
            reader.close();

            writer.close();

            inputFile.delete();

            tempFile.renameTo(inputFile);
 
            JOptionPane.showMessageDialog(this, field + " updated successfully!");

        } catch (IOException e) {

            e.printStackTrace();

            JOptionPane.showMessageDialog(this, "Failed to update " + field);

        }

    }

    private boolean PhoneNumberExists(String phone) {

    try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {

        String line;

        while ((line = br.readLine()) != null) {

            String[] phoneNumber = line.split("/");

            if (phoneNumber.length >= 5 && !phoneNumber[0].equals(username) && phoneNumber[4].equals(phone)) {

                return true;

            }

        }

    } catch (IOException e) {

        e.printStackTrace();

    }

    return false;

    }

    private boolean gmailExists(String email) {

    try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {

        String line;

        while ((line = br.readLine()) != null) {

            String[] gmail = line.split("/");

            if (gmail.length >= 6 && !gmail[0].equals(username) && gmail[5].equals(email)) {

                return true;

            }

        }

    } catch (IOException e) {

        e.printStackTrace();

    }

    return false;

}

    public void ensureFileExists() {
    File storeFile = new File("users.txt");
    
    if (!storeFile.exists()) {
        try {
            storeFile.createNewFile();
            System.out.println("Created new users.txt file");
        } catch (IOException e) {
            System.err.println("Failed to create users.txt: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
    
}

 