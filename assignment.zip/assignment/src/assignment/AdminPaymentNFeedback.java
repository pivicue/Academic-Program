package assignment;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class AdminPaymentNFeedback {
    private JTable feedbackTable;
    private DefaultTableModel tableModel;
    private JFrame mainFrame,editFrame;
    private JPanel panel,topPanel,bottomPanel,formPanel,fromBottomPanel;
    private JCheckBox cashBox, onlineBankingBox, creditCardBox;
    private JComboBox<String> searchOption;
    private JButton searchButton,backButton,refreshButton, saveButton, cancelButton, deleteButton;
    
    public AdminPaymentNFeedback(ActionListener onBack){
        mainFrame = new JFrame("Customer Feedback");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new BorderLayout());
        
        String[] columnNames = {"Customer","CarID","Rating", "Customer Feedback","Salesman Comment","Payment Method"};
        tableModel = new DefaultTableModel(columnNames, 0) {
        @Override
            public boolean isCellEditable(int row, int column) {
            return false;
    }
};
        feedbackTable = new JTable(tableModel);
        panel.add(feedbackTable);
        JScrollPane scrollPane = new JScrollPane(feedbackTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        String[] searchOptions = {"-","1", "2","3","4","5"};
        searchOption = new JComboBox<>(searchOptions);
        
        topPanel = new JPanel();
        searchButton = new JButton("Filter");
        refreshButton = new JButton("Refresh");
        topPanel.add(new JLabel("Filter rating:"));
        cashBox = new JCheckBox ("Cash");
        creditCardBox = new JCheckBox ("Credit Card");
        onlineBankingBox = new JCheckBox ("Online Banking");
        topPanel.add(searchOption);
        topPanel.add(searchButton);
        topPanel.add(refreshButton);
        topPanel.add(cashBox);
        topPanel.add(creditCardBox);
        topPanel.add(onlineBankingBox);        
        panel.add(topPanel, BorderLayout.NORTH);
        
        searchButton.addActionListener(e -> filterFeedback(tableModel));
        refreshButton.addActionListener(e -> loadFeedbackData(tableModel));
        cashBox.addActionListener(e -> {creditCardBox.setSelected(false);
                                   onlineBankingBox.setSelected(false);
                                   filterFeedback(tableModel);
        });
        creditCardBox.addActionListener(e -> {cashBox.setSelected(false);
                                   onlineBankingBox.setSelected(false);
                                   filterFeedback(tableModel);
        });
        onlineBankingBox.addActionListener(e -> {creditCardBox.setSelected(false);
                                   cashBox.setSelected(false);
                                   filterFeedback(tableModel);
        });
        
        bottomPanel = new JPanel();
        backButton = new JButton("Back");
        bottomPanel.add(backButton);
        backButton.addActionListener(onBack);
        panel.add(bottomPanel, BorderLayout.SOUTH);

        mainFrame.add(panel);
        mainFrame.pack();
        
        loadFeedbackData(tableModel);
        
    }
    
    public void loadFeedbackData(DefaultTableModel tableModel) {
        File file = new File("sale.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(mainFrame, "Could not create sale.txt");
                return;
            }
        }
        
        tableModel.setRowCount(0);
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length > 6) {
                    String feedback = (parts.length > 7 && !parts[7].trim().isEmpty()? parts[7] : "No Feedback");
                    Object[] rowData = {parts[0], parts[1], parts[6], feedback, parts[4],parts[5]};
                    tableModel.addRow(rowData);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(mainFrame, "Error reading from sale.txt: " + e.getMessage());
        }
    }
    
   private void filterFeedback(DefaultTableModel tableModel) {
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
    feedbackTable.setRowSorter(sorter);
    
    String selectedOption = (String) searchOption.getSelectedItem();
    List<RowFilter<DefaultTableModel, Integer>> filters = new ArrayList<>();
    
    switch (selectedOption) {
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
            filters.add(RowFilter.regexFilter(selectedOption, 2)); 
            break;
        case "-":
        default:
            sorter.setRowFilter(null); 
            break;
    }
    
    if (cashBox.isSelected()){
        filters.add(RowFilter.regexFilter("(?i)cash", 5));
    }
    if (creditCardBox.isSelected()){
        filters.add(RowFilter.regexFilter("(?i)credit card", 5));
    }
    if (onlineBankingBox.isSelected()){
        filters.add(RowFilter.regexFilter("(?i)online banking", 5));
    }
    
    if (!filters.isEmpty()) {
        sorter.setRowFilter(RowFilter.andFilter(filters));
    } else {
        sorter.setRowFilter(null); 
    }
}
    
    public JPanel getPanel(){
         return panel;
     }
}
