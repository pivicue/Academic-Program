package assignment;
import javax.swing.*;
import java.awt.*;

public class App {
    private JFrame frame;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private String currentUsername;
    private String adminCurrentUsername;
    private CustomerProfilePage customerProfilePage;
    private SuperAdminProfilePage superAdminProfilePage;
    private RegisterAdminPage registerAdminPage;
    private RegisterSalesmanPage registerSalesmanPage;
    private SalesmenProfilePage salesmenProfilePage;

    public App() {
        frame = new JFrame("APU Car Sales System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        
        MainPage mainPage = new MainPage(
                e -> cardLayout.show(cardPanel, "SuperAdminMainPage"),
                e -> cardLayout.show(cardPanel, "AdminLoginPage"),
                e -> cardLayout.show(cardPanel,"SalesmenMainPage"),
                e -> cardLayout.show(cardPanel, "CustomerMainPage"),
                e -> System.exit(0)
        );

        CustomerMainPage customerMainPage = new CustomerMainPage(
                e -> cardLayout.show(cardPanel, "CustomerLoginPage"),
                e -> cardLayout.show(cardPanel, "CustomerRegisterPage"),
                e -> cardLayout.show(cardPanel, "MainPage")
        );

        CustomerHomePage customerHomePage = new CustomerHomePage(
                e -> cardLayout.show(cardPanel,"CustomerProfilePage"),
                e -> cardLayout.show(cardPanel, "CustomerViewCarPage"),
                e -> cardLayout.show(cardPanel, "CustomerPurchaseHistory"),
                e -> cardLayout.show(cardPanel, "CustomerMainPage")
        );

        customerProfilePage = new CustomerProfilePage(
                "",
                e -> cardLayout.show(cardPanel, "CustomerHomePage")
        );
        
        CustomerPurchaseHistory customerPurchaseHistory = new CustomerPurchaseHistory(
                currentUsername,
                e -> cardLayout.show(cardPanel, "CustomerHomePage")
        );

        CustomerLoginPage customerLoginPage = new CustomerLoginPage(
            username -> {
                currentUsername = username;
                customerProfilePage.setUsername(currentUsername);
                customerPurchaseHistory.setUsername(currentUsername);
                customerProfilePage.loadUserInfo();
                cardLayout.show(cardPanel, "CustomerHomePage");
            }, 
            e -> cardLayout.show(cardPanel, "CustomerMainPage") 
        );
        
        CustomerViewCarPage customerViewCarPage = new CustomerViewCarPage(
                e -> cardLayout.show(cardPanel, "CustomerHomePage")
        );
       
        CustomerRegisterPage customerRegisterPage = new CustomerRegisterPage(
                e -> cardLayout.show(cardPanel, "CustomerMainPage"), 
                e -> cardLayout.show(cardPanel, "CustomerMainPage") 
        );
        
        SuperAdminMainPage superAdminMainPage = new SuperAdminMainPage (
                e -> cardLayout.show(cardPanel, "SuperAdminLoginPage"),
                e -> cardLayout.show(cardPanel, "SuperAdminRegisterPage"),
                e -> cardLayout.show(cardPanel, "MainPage")
        );
        
        SuperAdminRegisterPage superAdminRegisterPage = new SuperAdminRegisterPage(
                e -> cardLayout.show(cardPanel, "SuperAdminMainPage"), 
                e -> cardLayout.show(cardPanel, "SuperAdminMainPage")
        );
        
        SuperAdminLoginPage superAdminLoginPage = new SuperAdminLoginPage(
            username -> {
                currentUsername = username;
                superAdminProfilePage.setUsername(currentUsername);
                registerAdminPage.setUsername(currentUsername);
                registerSalesmanPage.setUsername(currentUsername);
                superAdminProfilePage.loadUserInfo();
                registerAdminPage.loadUserInfo();
                registerSalesmanPage.loadUserInfo();
                cardLayout.show(cardPanel, "SuperAdminHomePage");
            }, 
            e -> cardLayout.show(cardPanel, "SuperAdminMainPage") 
        );
        
        SuperAdminHomePage superAdminHomePage = new SuperAdminHomePage(
                e -> cardLayout.show(cardPanel,"SuperAdminProfilePage"),
                e -> cardLayout.show(cardPanel,"SearchAdminPage"),
                e -> cardLayout.show(cardPanel,"RegisterAdminPage"),
                e -> cardLayout.show(cardPanel,"RegisterSalesmanPage"),
                e -> cardLayout.show(cardPanel, "SuperAdminMainPage")
        );
        
         SearchAdminPage searchAdminPage= new SearchAdminPage(
                e -> cardLayout.show(cardPanel, "SuperAdminHomePage")
        );
        
        superAdminProfilePage = new SuperAdminProfilePage(
                "",
                e -> cardLayout.show(cardPanel, "SuperAdminHomePage")
        );
        
        registerAdminPage = new RegisterAdminPage(
                "",
                e -> cardLayout.show(cardPanel, "SuperAdminHomePage"),
                e -> cardLayout.show(cardPanel, "SuperAdminHomePage")
        );
        
        registerSalesmanPage = new RegisterSalesmanPage(
                "",
                e -> cardLayout.show(cardPanel, "SuperAdminHomePage"),
                e -> cardLayout.show(cardPanel, "SuperAdminHomePage")
        );
        
        CollectPaymentAndReviewPage collectPaymentAndReviewPage= new CollectPaymentAndReviewPage(
                currentUsername,
                e -> cardLayout.show(cardPanel,"SalesmenHomePage")
        );
        
        UpdateCarStatus updateCarStatus = new UpdateCarStatus(
                currentUsername,
                e -> cardLayout.show(cardPanel,"SalesmenHomePage")
        );
        
        ViewSalesRecordPage viewSalesRecordPage = new ViewSalesRecordPage(
                currentUsername,
                e -> cardLayout.show(cardPanel,"SalesmenHomePage")
        );
        
        SalesmenMainPage salesmenMainPage = new SalesmenMainPage(
                e -> cardLayout.show(cardPanel, "SalesmenLoginPage"),
                e -> cardLayout.show(cardPanel, "MainPage")
        );
        SalesmenLoginPage salesmenLoginPage = new SalesmenLoginPage(
            username -> {
                currentUsername = username;
                salesmenProfilePage.setUsername(currentUsername);
                updateCarStatus.setUsername(currentUsername);
                collectPaymentAndReviewPage.setUsername(currentUsername);
                viewSalesRecordPage.setUsername(currentUsername);
                salesmenProfilePage.loadUserInfo();
                cardLayout.show(cardPanel, "SalesmenHomePage");
            }, 
            e -> cardLayout.show(cardPanel, "SalesmenMainPage") 
        );
        SalesmenHomePage salesmenHomePage = new SalesmenHomePage(
                e -> cardLayout.show(cardPanel,"SalesmenProfilePage"),
                e -> cardLayout.show(cardPanel, "UpdateCarStatus"),
                e -> cardLayout.show(cardPanel, "CollectPaymentAndReviewPage"),
                e -> cardLayout.show(cardPanel, "ViewSalesRecordPage"),
                e -> cardLayout.show(cardPanel, "SalesmenMainPage")
        );
        salesmenProfilePage = new SalesmenProfilePage(
                "",
                e -> cardLayout.show(cardPanel, "SalesmenHomePage")
        );
               
 
        AdminProfilePage adminProfilePage= new AdminProfilePage(
                "",
                e -> cardLayout.show(cardPanel,"AdminMainPage")
        );
        AdminMainPage adminMainPage = new AdminMainPage(
 
                e -> cardLayout.show(cardPanel,"AdminProfilePage"),
                e -> cardLayout.show(cardPanel,"AdminSearchSalesman"),
                e -> cardLayout.show(cardPanel,"AdminCustomerPage"),
                e -> cardLayout.show(cardPanel,"AdminCarPage"),
                e -> cardLayout.show(cardPanel,"AdminPaymentNFeedback"),
                e -> cardLayout.show(cardPanel,"MainPage")
 
        );
        AdminPaymentNFeedback adminPaymentNFeedback = new AdminPaymentNFeedback(
                e -> cardLayout.show(cardPanel,"AdminMainPage")
        );
        
        AdminCarPage adminCarPage = new AdminCarPage(
                e -> cardLayout.show(cardPanel,"AdminSearchCarPage"),
                e -> cardLayout.show(cardPanel,"AdminAddCarPage"),
                e -> cardLayout.show(cardPanel,"AdminMainPage")
        );
        
        AdminCustomerPage adminCustomerPage = new AdminCustomerPage(
                e -> cardLayout.show(cardPanel,"AdminSearchCustomer"),
                e -> cardLayout.show(cardPanel,"AdminApproveCustomer"),
                e -> cardLayout.show(cardPanel,"AdminMainPage")
        );
        
        AdminApproveCustomer adminApproveCustomer = new AdminApproveCustomer(
                e -> cardLayout.show(cardPanel,"AdminCustomerPage")
        );
        
        AdminSearchCarPage adminSearchCarPage = new AdminSearchCarPage(
                adminCurrentUsername,
                e -> cardLayout.show(cardPanel,"AdminCarPage")
);
         AdminSearchCustomer adminSearchCustomer = new AdminSearchCustomer(
                e -> cardLayout.show(cardPanel,"AdminCustomerPage")
);
         
        AdminSearchSalesman adminSearchSalesman = new AdminSearchSalesman(
                e -> cardLayout.show(cardPanel,"AdminMainPage")
        );
        
        AdminAddCarPage adminAddCarPage = new AdminAddCarPage(
                adminCurrentUsername,
                e -> cardLayout.show(cardPanel,"AdminCarPage")
        );

        
        AdminLoginPage adminLoginPage = new AdminLoginPage(
            username ->{
                adminCurrentUsername = username;
                adminProfilePage.setUsername(adminCurrentUsername);
                adminProfilePage.loadUserInfo();
                adminSearchCarPage.setUsername(adminCurrentUsername);
                adminAddCarPage.setUsername(adminCurrentUsername);
                cardLayout.show(cardPanel, "AdminMainPage");
        },
            e -> cardLayout.show(cardPanel, "MainPage")
        );
        cardPanel.add(mainPage, "MainPage");
        
        cardPanel.add(superAdminMainPage, "SuperAdminMainPage");
        cardPanel.add(superAdminRegisterPage, "SuperAdminRegisterPage");
        cardPanel.add(superAdminLoginPage, "SuperAdminLoginPage");
        cardPanel.add(superAdminHomePage, "SuperAdminHomePage");
        cardPanel.add(superAdminProfilePage, "SuperAdminProfilePage");
        cardPanel.add(registerAdminPage, "RegisterAdminPage");
        cardPanel.add(registerSalesmanPage, "RegisterSalesmanPage");
        cardPanel.add(searchAdminPage, "SearchAdminPage");
        
        cardPanel.add(adminProfilePage.getPanel(),"AdminProfilePage");
        cardPanel.add(adminLoginPage.getPanel(),"AdminLoginPage");
        cardPanel.add(adminMainPage.getPanel(),"AdminMainPage");
        cardPanel.add(adminSearchCustomer.getPanel(), "AdminSearchCustomer");
        cardPanel.add(adminSearchSalesman.getPanel(), "AdminSearchSalesman");
        cardPanel.add(adminCustomerPage.getPanel(), "AdminCustomerPage");
        cardPanel.add(adminApproveCustomer.getPanel(), "AdminApproveCustomer");
        cardPanel.add(adminCarPage.getPanel(), "AdminCarPage");
        cardPanel.add(adminAddCarPage.getPanel(), "AdminAddCarPage");
        cardPanel.add(adminSearchCarPage.getPanel(), "AdminSearchCarPage");
        cardPanel.add(adminPaymentNFeedback.getPanel(), "AdminPaymentNFeedback");
        
        cardPanel.add(customerMainPage, "CustomerMainPage");
        cardPanel.add(customerLoginPage, "CustomerLoginPage");
        cardPanel.add(customerRegisterPage, "CustomerRegisterPage");
        cardPanel.add(customerHomePage, "CustomerHomePage");
        cardPanel.add(customerProfilePage, "CustomerProfilePage");
        cardPanel.add(customerViewCarPage, "CustomerViewCarPage");
        cardPanel.add(customerPurchaseHistory, "CustomerPurchaseHistory");
        
        cardPanel.add(salesmenMainPage, "SalesmenMainPage");
        cardPanel.add(salesmenLoginPage, "SalesmenLoginPage");
        cardPanel.add(salesmenHomePage, "SalesmenHomePage");
        cardPanel.add(salesmenProfilePage, "SalesmenProfilePage");
        cardPanel.add(collectPaymentAndReviewPage,"CollectPaymentAndReviewPage");
        cardPanel.add(viewSalesRecordPage,"ViewSalesRecordPage");
        cardPanel.add(updateCarStatus,"UpdateCarStatus");
        
        frame.add(cardPanel);
        cardLayout.show(cardPanel, "MainPage");
        frame.setVisible(true);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        new App();
    }
}