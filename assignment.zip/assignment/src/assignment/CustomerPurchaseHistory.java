package assignment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerPurchaseHistory extends JPanel {
    private String username;
    private JTable table;
    private DefaultTableModel model;
    private JTextArea detailArea;
    private JTextField ratingField;
    private JTextArea feedbackArea;
    private JButton saveButton;
    private JButton backButton;
    private List<Sale> saleList = new ArrayList<>();

    public CustomerPurchaseHistory(String username, ActionListener onBack) {
        this.username = username;
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"ID", "Brand", "Amount", "Payment Method"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        detailArea = new JTextArea(8, 30);
        detailArea.setEditable(false);

        ratingField = new JTextField();
        feedbackArea = new JTextArea(4, 20);
        saveButton = new JButton("Save Feedback");

        JPanel rightPanel = new JPanel(new BorderLayout());
        JPanel formPanel = new JPanel(new GridLayout(5, 1));
        formPanel.add(new JLabel("Rating (1-5):"));
        formPanel.add(ratingField);
        formPanel.add(new JLabel("Feedback:"));
        formPanel.add(new JScrollPane(feedbackArea));
        formPanel.add(saveButton);

        rightPanel.add(new JScrollPane(detailArea), BorderLayout.CENTER);
        rightPanel.add(formPanel, BorderLayout.SOUTH);

        add(scrollPane, BorderLayout.WEST);
        add(rightPanel, BorderLayout.CENTER);

        backButton = new JButton("Back");
        backButton.addActionListener(onBack);

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    Sale selected = saleList.get(row);
                    detailArea.setText(selected.toDetailString());
                    ratingField.setText(selected.rating);
                    feedbackArea.setText(selected.feedback);
                }
            }
        });

        saveButton.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String ratingText = ratingField.getText().trim();
                if (!ratingText.matches("[1-5]")) {
                    JOptionPane.showMessageDialog(this, "Rating must be an integer between 1 and 5.");
                    return;
                }

                Sale selected = saleList.get(row);
                selected.rating = ratingText;
                selected.feedback = feedbackArea.getText().trim();
                saveSalesToFile();
                detailArea.setText(selected.toDetailString());
                JOptionPane.showMessageDialog(this, "Feedback saved.");
            }
        });

        refresh();
    }

    public void refresh() {
        loadSalesFromFile();
        clearInputFields();
    }

    private void clearInputFields() {
        detailArea.setText("");
        ratingField.setText("");
        feedbackArea.setText("");
        table.clearSelection();
    }

    public void loadSalesFromFile() {
        File file = new File("sale.txt");
        if (!file.exists()) {
            saleList.clear();
            model.setRowCount(0);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            saleList.clear();
            model.setRowCount(0);
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 6 && parts[0].equals(username)) {
                    String customer = parts[0];
                    String id = parts[1];
                    String brand = parts[2];
                    double amount = Double.parseDouble(parts[3]);
                    String comment = parts[4];
                    String paymentMethod = parts[5];
                    String rating = parts.length > 6 ? parts[6] : "";
                    String feedback = parts.length > 7 ? parts[7] : "";

                    Sale s = new Sale(customer, id, brand, amount, comment, paymentMethod, rating, feedback);
                    saleList.add(s);
                    model.addRow(new Object[]{id, brand, amount, paymentMethod});
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading sale.txt: " + ex.getMessage());
        }
    }

    public void setUsername(String username) {
        this.username = username;
        refresh();
    }

    private void saveSalesToFile() {
        List<Sale> allSales = new ArrayList<>();
        File file = new File("sale.txt");
        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 6) {
                        String customer = parts[0];
                        String id = parts[1];
                        String brand = parts[2];
                        double amount = Double.parseDouble(parts[3]);
                        String comment = parts[4];
                        String paymentMethod = parts[5];
                        String rating = parts.length > 6 ? parts[6] : "";
                        String feedback = parts.length > 7 ? parts[7] : "";
                        if (!customer.equals(username)) {
                            allSales.add(new Sale(customer, id, brand, amount, comment, paymentMethod, rating, feedback));
                        }
                    }
                }
            } catch (IOException | NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Error reading sale.txt: " + ex.getMessage());
                return;
            }
        }

        allSales.addAll(saleList);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            for (Sale s : allSales) {
                writer.write(s.toFileString());
                writer.newLine();
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving sale.txt: " + ex.getMessage());
        }
    }

    static class Sale {
        String customer;
        String id;
        String brand;
        double amount;
        String comment;
        String paymentMethod;
        String rating;
        String feedback;

        public Sale(String customer, String id, String brand, double amount, String comment, String paymentMethod, String rating, String feedback) {
            this.customer = customer;
            this.id = id;
            this.brand = brand;
            this.amount = amount;
            this.comment = comment;
            this.paymentMethod = paymentMethod;
            this.rating = rating;
            this.feedback = feedback;
        }

        public String toDetailString() {
            return String.format(
                    "ID: %s\nBrand: %s\nAmount: $%.2f\nPayment Method: %s\nComment: %s\nRating: %s\nFeedback: %s",
                    id, brand, amount, paymentMethod, comment,
                    rating.isEmpty() ? "Not rated" : rating,
                    feedback.isEmpty() ? "No feedback" : feedback
            );
        }

        public String toFileString() {
            return String.join("|", customer, id, brand, String.valueOf(amount), comment, paymentMethod, rating, feedback);
        }
    }
}
