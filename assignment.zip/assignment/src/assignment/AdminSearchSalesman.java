package assignment;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class AdminSearchSalesman {
    private JTable salesmanTable;
    private DefaultTableModel tableModel;
    private JPanel panel,topPanel,bottomPanel,formPanel,fromBottomPanel;
    private JFrame mainFrame,editFrame;
    private JButton searchButton,backButton, editButton,refreshButton, saveButton, cancelButton, deleteButton;
    private JTextField searchField,usernameField,emailField,addressField,phoneField;
    private JComboBox<String> searchOption;
    private int selectedRow = -1;
    private String currentUsername;
    private JSpinner DateOfBirthSpinner;
     
     public AdminSearchSalesman(ActionListener onBack) {
        mainFrame = new JFrame("Search Salesman");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new BorderLayout());
        
        String[] columnNames = {"Name","Date of Birth", "Phone.no","Address", "Email", "Created By"};
        tableModel = new DefaultTableModel(columnNames, 0) {
        @Override
            public boolean isCellEditable(int row, int column) {
            return false;
    }
};

        salesmanTable = new JTable(tableModel);
        panel.add(salesmanTable);
        JScrollPane scrollPane = new JScrollPane(salesmanTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        String[] searchOptions = {"-","Name", "Date of Birth","Phone.no","Address","Email","Created by"};
        searchOption = new JComboBox<>(searchOptions);
        
        topPanel = new JPanel();
        searchField = new JTextField(15);
        searchButton = new JButton("Search");
        refreshButton = new JButton("Refresh");
        topPanel.add(searchOption);
        topPanel.add(new JLabel("Search:"));
        topPanel.add(searchField);
        topPanel.add(searchButton);
        topPanel.add(refreshButton);
        panel.add(topPanel, BorderLayout.NORTH);
        
        searchButton.addActionListener(e -> filterSalesman(tableModel));
        searchField.addActionListener(e -> filterSalesman(tableModel));
        refreshButton.addActionListener(e -> loadSalesmanData(tableModel));

        editButton = new JButton("Edit");
        backButton = new JButton("Back");
        editButton.addActionListener(e -> editPage());
        backButton.addActionListener(onBack);
        bottomPanel = new JPanel();
        bottomPanel.add(editButton);
        bottomPanel.add(backButton);
        panel.add(bottomPanel, BorderLayout.SOUTH);
       
        mainFrame.add(panel);
        mainFrame.pack();
        
        
        loadSalesmanData(tableModel);
        
        salesmanTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selectedRow = salesmanTable.getSelectedRow();
            }
        });
    
        

        
}
     public void loadSalesmanData(DefaultTableModel tableModel) {
        File file = new File("Salesman.txt");
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(mainFrame, "Could not create Salesman.txt");
                return;
            }
        }
        
        tableModel.setRowCount(0);
        
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length == 7) {
                    Object[] rowData = {parts[0], parts[2], parts[4], parts[3], parts[5], parts[6],};
                    tableModel.addRow(rowData);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(mainFrame, "Error reading from Salesman.txt: " + e.getMessage());
        }
    }
    private void filterSalesman(DefaultTableModel tableModel){
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
    salesmanTable.setRowSorter(sorter);
    List<RowFilter<DefaultTableModel, Integer>> filters = new ArrayList<>();
    String searchText = searchField.getText().trim();
    sorter.setRowFilter(RowFilter.andFilter(filters));
    if (!searchText.isEmpty()) {
        String selectedOption = (String) searchOption.getSelectedItem();
        String safeSearchText = Pattern.quote(searchText);
        switch (selectedOption) {
            case "Name":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 0));
                break;
            case "Date of Birth":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 1));
                break;
            case "Address":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 3));
                break;
            case "Phone.no":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 2));
                break;
            case "Email":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 4));
                break;
            case "Created by":
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText, 5));
                break;
            case "-":
            default:
                filters.add(RowFilter.regexFilter("(?i)" + safeSearchText));
                break;
        }
    }
    if (!filters.isEmpty()) {
            sorter.setRowFilter(RowFilter.andFilter(filters));
       }else {
            sorter.setRowFilter(null); 
        }
    }

    
    private void editPage(){
        selectedRow = salesmanTable.getSelectedRow();
        
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(editFrame,"Please choose a salesman to edit");
            return;
        }
        
        int modelRow = salesmanTable.convertRowIndexToModel(selectedRow);
        currentUsername = (String) tableModel.getValueAt(modelRow, 0);
                
        editFrame = new JFrame("Edit Salesman Profile");
        editFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        panel = new JPanel(new BorderLayout());
        editFrame.setSize(800, 600);
        editFrame.setLocationRelativeTo(null);
        
        usernameField = new JTextField(); 
        addressField = new JTextField();
        phoneField = new JTextField();
        emailField = new JTextField();
        SpinnerDateModel dateModel = new SpinnerDateModel();
        DateOfBirthSpinner = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(DateOfBirthSpinner, "yyyy-MM-dd");
        DateOfBirthSpinner.setEditor(dateEditor);
        
        usernameField.setEditable(false);
        formPanel = new JPanel(new GridLayout(5, 2));
        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Date of Birth:"));
        formPanel.add(DateOfBirthSpinner);
        formPanel.add(new JLabel("Address:"));
        formPanel.add(addressField);
        formPanel.add(new JLabel("Phone.no:"));
        formPanel.add(phoneField);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(emailField);
        
        fromBottomPanel = new JPanel(new GridLayout(1,3));
        saveButton =new JButton("Save");
        saveButton.addActionListener(e-> saveChange());
        fromBottomPanel.add(saveButton);
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(e-> deleteProfile());
        fromBottomPanel.add(deleteButton);
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e-> editFrame.dispose());
        fromBottomPanel.add(cancelButton);

        editFrame.add(formPanel,BorderLayout.CENTER);
        editFrame.add(fromBottomPanel,BorderLayout.SOUTH);
        editFrame.setVisible(true);
        
        loadProfile();
        
        

    }
    private void loadProfile(){
        try (BufferedReader br = new BufferedReader(new FileReader("Salesman.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 6 && parts[0].equals(currentUsername)) {
                    usernameField.setText(parts[0]);
                    try {
                        Date dob = new SimpleDateFormat("yyyy-MM-dd").parse(parts[2]);
                        DateOfBirthSpinner.setValue(dob);
                    } catch (Exception e) {
                        DateOfBirthSpinner.setValue(new Date());
                    }
                    phoneField.setText(parts[4]);
                    addressField.setText(parts[3]);
                    emailField.setText(parts[5]);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void saveChange() {
    Date selectedDate = (Date) DateOfBirthSpinner.getValue();
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    
    String dob = dateFormat.format(selectedDate);        
    String phone = phoneField.getText();
    String address = addressField.getText();
    String email = emailField.getText();
    
    if(checkExist()){
    
    try(BufferedReader reader = new BufferedReader(new FileReader("Salesman.txt"))) {
        ArrayList<String> lines = new ArrayList<>();
        String line;
        
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split("/");
            
            if (phoneField.getText().isEmpty())
                phone = parts[4];
            if(addressField.getText().isEmpty())
                address = parts[3];
            if(emailField.getText().isEmpty())
                email = parts[5];
    
            if (parts.length >= 6 && parts[0].equals(currentUsername)) {

                parts[2] = dob;
                parts[3] = address;
                parts[4] = phone;
                parts[5] = email;
                line = String.join("/", parts);
            }
            lines.add(line);
        }
        reader.close();
        
        // Write all lines back to the file (overwrite, not append)
        try (PrintWriter writer = new PrintWriter(new FileWriter("Salesman.txt"))) {
            for (String updatedLine : lines) {
                writer.println(updatedLine);
            }
        }

        JOptionPane.showMessageDialog(editFrame, "Changes saved successfully!");
        editFrame.dispose();
        loadSalesmanData(tableModel);
            
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(editFrame, "Failed to update: " + e.getMessage());
    }
    }
}   
    public void deleteProfile(){
        if (currentUsername == null || currentUsername.isEmpty()) {
        JOptionPane.showMessageDialog(mainFrame, "Please select a salesman to delete");
        return;
    }
        int confirm = JOptionPane.showConfirmDialog(mainFrame, 
            "Delete " + currentUsername + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
        return; 
        }
        
        
        List<String> lines = new ArrayList<>();
        try(BufferedReader reader = new BufferedReader(new FileReader("Salesman.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
            String[] parts = line.split("/");
                 if (parts.length >= 6 && !parts[0].equals(currentUsername)) {
                    lines.add(line); 
                 }
            }
        }catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(editFrame, "Failed to update: " + e.getMessage());
    }
        try (PrintWriter writer = new PrintWriter(new FileWriter("Salesman.txt"))) {
        for (String line : lines) {
            writer.println(line);
        }
        JOptionPane.showMessageDialog(mainFrame, "Salesman "+currentUsername+ " deleted successfully!");
    } catch (IOException e) {
        JOptionPane.showMessageDialog(mainFrame, "Error writing file: " + e.getMessage());
    }
        
    editFrame.dispose();
    currentUsername = null;
    loadSalesmanData(tableModel); 
}
    
   private boolean checkExist(){
        String input;
        if (!phoneField.getText().isEmpty()) {
                input = phoneField.getText();
            if (!input.matches("01\\d{8}")) {
                JOptionPane.showMessageDialog(editFrame, "Please enter a correct phone number.");
                return false;
        }
            if (PhoneNumberExists(input)) {
                JOptionPane.showMessageDialog(editFrame, "Phone number already exists.");
                return false;
        }
    }
        if (!emailField.getText().isEmpty()) {
            input = emailField.getText();
            if (!input.matches("^[A-Za-z0-9+_.-]+@gmail\\.com$")) {
                JOptionPane.showMessageDialog(editFrame, "Invalid Gmail format.");
                return false;
        }
            if (gmailExists(input)) {
                JOptionPane.showMessageDialog(editFrame, "Gmail already exists.");
                return false;
        }
    }
        return true;
}
        
        private boolean PhoneNumberExists(String phone) {
        try (BufferedReader br = new BufferedReader(new FileReader("Salesman.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] phoneNumber = line.split("/");
            if (phoneNumber.length >= 5 && !phoneNumber[0].equals(currentUsername) && phoneNumber[4].equals(phone)) {
                return true;
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
        return false;
    }
    
    private boolean gmailExists(String email) {
        try (BufferedReader br = new BufferedReader(new FileReader("Salesman.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] gmail = line.split("/");
            if (gmail.length >= 6 && !gmail[0].equals(currentUsername) && gmail[5].equals(email)) {
                return true;
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return false;
}
    
    public JPanel getPanel(){
         return panel;
     }
}

