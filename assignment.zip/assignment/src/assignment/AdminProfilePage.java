package assignment;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.*;

public class AdminProfilePage {
    private String username;
    private JFrame frame;
    private JPanel panel;
    private JButton editPasswordButton, editDateOfBirthButton, editAddressButton, editPhoneButton,
                    editEmailButton, backButton;  
    private JTextField usernameField, addressField, phoneField, emailField, dateOfBirthField;
    private JPasswordField passwordField;
    private JCheckBox showPassword;
                
    public AdminProfilePage(String username, ActionListener onBack){
        this.username = username;
        
        frame = new JFrame("AdminProfile");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel(new GridLayout(8,3,5,5));
        
        editPasswordButton = new JButton("Edit");
        editDateOfBirthButton = new JButton("Edit");
        editAddressButton = new JButton("Edit");
        editPhoneButton = new JButton("Edit");
        editEmailButton = new JButton("Edit");
        backButton = new JButton("Back");
        showPassword = new JCheckBox("Show Password");
        
        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);
        usernameField.setEditable(false);
        panel.add(new JLabel(""));
        
        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);
        panel.add(editPasswordButton);
        passwordField.setEditable(false);
        
        panel.add(new JLabel("Date Of Birth:"));
        dateOfBirthField = new JTextField();
        panel.add(dateOfBirthField);
        dateOfBirthField.setEditable(false);
        panel.add(new JLabel(""));
        
        panel.add(new JLabel("Address:"));
        addressField = new JTextField();
        panel.add(addressField);
        panel.add(editAddressButton);
        addressField.setEditable(false);
        
        panel.add(new JLabel("Phone.NO:"));
        phoneField = new JTextField();
        panel.add(phoneField);
        panel.add(editPhoneButton);
        phoneField.setEditable(false);
        
        panel.add(new JLabel("Email:"));
        emailField = new JTextField();
        panel.add(emailField);
        panel.add(editEmailButton);
        emailField.setEditable(false);
        
        panel.add(new JLabel(""));
        panel.add(backButton);
       
        
        
        editPasswordButton.addActionListener( e-> promptAndUpdate("Password"));
        editAddressButton.addActionListener( e-> promptAndUpdate("Address"));
        editPhoneButton.addActionListener( e-> promptAndUpdate("Phone.No"));
        editEmailButton.addActionListener( e-> promptAndUpdate("Email"));
        backButton.addActionListener(onBack);
       
        
        frame.add(panel);
        
        loadUserInfo();

        }
    
    private void promptAndUpdate(String field){
        if(field.equals("Password")){
            String oldPasswordInput = showPasswordInputDialog(frame, "Enter current password:");
            if (oldPasswordInput == null || !oldPasswordInput.equals(new String(passwordField.getPassword()))) {
            JOptionPane.showMessageDialog(frame, "Incorrect password.");
            return;   
            }
            String newPassword = showPasswordInputDialog(frame, "Enter new password:");
            if (newPassword.equals(oldPasswordInput)){
                JOptionPane.showMessageDialog(frame, "Please enter a new Password");
                return;
         }
            else if (newPassword.length()<6 || newPassword.isEmpty()){
                    JOptionPane.showMessageDialog(frame, "Please enter password at least 6 digit!");
                     return;
            }
        updateFieldInFile(field, newPassword);
        loadUserInfo();
        return; 
       
        }
        String current = switch (field) {
        case "Address" -> addressField.getText();
        case "Phone" -> phoneField.getText();
        case "Email" -> emailField.getText();
        default -> "";
    };
 
        String input = JOptionPane.showInputDialog(frame, "Enter new " + field + ":", current);
        if (input == null || input.trim().isEmpty()) return;
        input = input.trim();
        if (field.equals("Phone")) {
            if (!input.matches("01\\d{8}")) {
                JOptionPane.showMessageDialog(frame, "Please enter a correct phone number.");
                return;
        }
            if (PhoneNumberExists(input)) {
                JOptionPane.showMessageDialog(frame, "Phone number already exists.");
                return;
        }
    }
        if (field.equals("Email")) {
            if (!input.matches("^[A-Za-z0-9+_.-]+@gmail\\.com$")) {
                JOptionPane.showMessageDialog(frame, "Invalid Gmail format.");
                return;
        }
            if (gmailExists(input)) {
                JOptionPane.showMessageDialog(frame, "Gmail already exists.");
                return;
        }
    }
        updateFieldInFile(field, input);
        loadUserInfo();
}
    
    
    public void loadUserInfo() {
        ensureFileExists();
        try (BufferedReader br = new BufferedReader(new FileReader("Admin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 6 && parts[0].equals(username)) {
                    usernameField.setText(username);
                    passwordField.setText(parts[1]);
                    dateOfBirthField.setText(parts[2]);
                    addressField.setText(parts[3]);
                    phoneField.setText(parts[4]);
                    emailField.setText(parts[5]);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
    private String showPasswordInputDialog(Component parent, String message) {
    JPanel panel = new JPanel(new BorderLayout());
    JLabel label = new JLabel(message);
    JPasswordField passwordField = new JPasswordField(15);
    JCheckBox showPasswordCheckBox = new JCheckBox("Show Password");
    showPasswordCheckBox.addActionListener(e -> {
        passwordField.setEchoChar(showPasswordCheckBox.isSelected() ? (char) 0 : '•');
    });
    JPanel inputPanel = new JPanel(new BorderLayout());
    inputPanel.add(passwordField, BorderLayout.CENTER);
    inputPanel.add(showPasswordCheckBox, BorderLayout.SOUTH);
    panel.add(label, BorderLayout.NORTH);
    panel.add(inputPanel, BorderLayout.CENTER);
    int option = JOptionPane.showConfirmDialog(parent, panel, "Password", 
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (option == JOptionPane.OK_OPTION) {
        return new String(passwordField.getPassword()).trim();
    } else {
        JOptionPane.showMessageDialog(parent, "Failed to edit password");
        return null;
    }
    }
    
    private void updateFieldInFile(String field, String newValue) {
        try {
            File inputFile = new File("Admin.txt");
            File tempFile = new File("Admin_temp.txt");
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("/");
                if (parts.length >= 6 && parts[0].equals(username)) {
                    switch (field) {
                        case "Password" -> parts[1] = newValue;
                        case "Address" -> parts[3] = newValue;
                        case "Phone" -> parts[4] = newValue;
                        case "Email" -> parts[5] = newValue;
                    }
                    line = String.join("/", parts);
                }
                writer.write(line);
                writer.newLine();
            }
            reader.close();
            writer.close();
            inputFile.delete();
            tempFile.renameTo(inputFile);
            JOptionPane.showMessageDialog(frame, field + " updated successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to update " + field);
        }
    }
    
    private boolean PhoneNumberExists(String phone) {
        try (BufferedReader br = new BufferedReader(new FileReader("Admin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] phoneNumber = line.split("/");
            if (phoneNumber.length >= 5 && !phoneNumber[0].equals(username) && phoneNumber[4].equals(phone)) {
                return true;
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
        return false;
    }
    
    private boolean gmailExists(String email) {
        try (BufferedReader br = new BufferedReader(new FileReader("Admin.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] gmail = line.split("/");
            if (gmail.length >= 6 && !gmail[0].equals(username) && gmail[5].equals(email)) {
                return true;
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return false;
}
    
    public void ensureFileExists() {
    File storeFile = new File("Admin.txt");
    
    if (!storeFile.exists()) {
        try {
            storeFile.createNewFile();
            System.out.println("Created new Admin.txt file");
        } catch (IOException e) {
            System.err.println("Failed to create Admin.txt: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
    
    public void setUsername(String username) {
    this.username = username;
}
    
    public JPanel getPanel() {
        return panel;
    }
}

